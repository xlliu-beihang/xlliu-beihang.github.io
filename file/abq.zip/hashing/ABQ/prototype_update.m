function [P, C] = prototype_update(P, C, I, X, lambda)

k = size(P, 1);
n = size(X, 1);

w = single(zeros(1, k));
for i = 1:k
    w(i) = numel(find(I == i));
end

distX2P = distMat(X, P);
loss = zeros(n, k); % Quantization loss of X(i) when assigned to P(j)
W = repmat(w, [n 1]);
for j = 1:k
    loss(:, j) = sum(W.*bsxfun(@minus, lambda*distX2P(:, :), dh(C(j), C)).^2, 2);
end

[~, I] = min(loss, [], 2);

% Update prototype set, while uninformative ones are eliminated
k_new = 0;
for i = 1:k
    Xi = X(I == i, :);
    if ~isempty(Xi)
        k_new = k_new+1;
        P_new(k_new, :) = mean(Xi, 1);
        C_new(k_new, 1) = C(i);
    end
end
P = P_new;
C = C_new;

end
