function [ param ] = trainABQ( X, param )

X = single(X);

b = param.b;            % Number of bits in each subspace
M = param.nbits / b;	% Number of subspaces
dim = size(X, 2);
iter = param.iter;

if b > 8
    error('Required b <= 8.');
end

% Perform optimized product quantization
[param.R, param.sample_mean] = projection_optimized_product_quantization(X, M);
X = project(X, param.R, param.sample_mean);
X_sub = cell(1, M);
parfor m = 1:M
    X_sub{m} = X(:, (m-1)*(dim/M)+1 : m*(dim/M));
end
clear X;

P = cell(1, M);     % Prototype set
C = cell(1, M);     % Codes of prototypes

parfor m = 1:M
    % Initialize the assignment index i*(X) and the prototype set P using k-means;
    [P{m}, ~, I] = yael_kmeans(X_sub{m}', 2^b, 'verbose', 0);
    P{m} = P{m}';
    
    % Initialize the scale parameter according to (11);
    lambda = mean(mean(dh(uint8(0:2^b-1)', uint8(0:2^b-1)'))) ...
        / mean(mean(distMat(X_sub{m}, P{m})));
    
    for i = 1:iter
        % Find the local optimal codes C for P by solving (6);
        C{m} = adaptive_coding(P{m}, uint8(C{m}), I, X_sub{m}, lambda, b);
        
        % Update the prototype set P according to (8) and (9);
        [P{m}, C{m}] = prototype_update(P{m}, C{m}, I, X_sub{m}, lambda);
        
        % Update the distribution i*(X) according to (10);
        [I, ~] = yael_nn(P{m}', single(X_sub{m})');
    end
end

param.P = P;
param.C = C;

end
