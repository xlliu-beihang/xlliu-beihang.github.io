function [ evaluation_info ] = evaluateABQ( data, param )

tic;
param = trainABQ(data.train_data', param);
trainT = toc;

tic;
B_tst = compressABQ(data.test_data', param);
compressT = toc;
B_db = compressABQ(data.db_data', param);

evaluation_info = performance(B_tst, B_db, data.groundtruth, param);
evaluation_info.trainT = trainT;
evaluation_info.compressT = compressT;
end

