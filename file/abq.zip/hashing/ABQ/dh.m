function [ D ] = dh( B1, B2 )

global dh_table;
if isempty(dh_table)
    dh_table = single(hammingDist(uint8(0:255)', uint8(0:255)')).^0.5;
end

D = dh_table(uint16(B1)+1, uint16(B2)+1);

end
