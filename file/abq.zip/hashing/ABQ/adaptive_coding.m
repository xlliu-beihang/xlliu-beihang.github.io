function C = adaptive_coding(P, C, I, X, lambda, b)

k = size(P, 1); % Number of prototypes(codes)

C_all = uint8(0:2^b-1)';
C_unused = setdiff(C_all, C);

w = single(zeros(1, k));
for i = 1:k
    w(i) = numel(find(I == i));
end

distX2P = distMat(X, P);
for i = 1:k
    % Search for a locally optimal code; If P(k) is already assigned a
    % code, seek for a better one
    if i <= numel(C)
        C_unused = [C_unused; C(i)];
    elseif i == 1
            % Initialize the first one
            C(1) = uint8(0);
            C_unused = setdiff(C_unused, C(1));
            continue;
    end
    
    idx_other_p = [1:i-1 i+1:numel(C)];     % Indices of prototypes assigned
    idx_other_x = ismember(I, idx_other_p);
    do1 = distX2P(I==i, idx_other_p);       % 1: the first part of Eqn(6)
    dh1 = dh(C_unused, C(idx_other_p));
    do2 = distX2P(idx_other_x, i);          % 2: the second part
    dh2 = dh(C(I(idx_other_x)), C_unused);
    W = repmat(w, [numel(find(I==i)) 1]);
    loss = zeros(size(C_unused, 1), 1);
    for j = 1:size(C_unused, 1)
        loss(j) = sum(sum(W(:, idx_other_p) .* (bsxfun(@minus, lambda*do1, dh1(j, :)).^2))) + ...
            sum(w(i) * (lambda*do2 - dh2(:, j)).^2);
    end
    
    [~, ii] = min(loss);
    C(i, 1) = C_unused(ii);
    C_unused = setdiff(C_unused, C(i));
end

end
