function bin = compressABQ( X, param )

P = param.P;
C = param.C;
dim = size(X, 2);
M = param.nbits / param.b;

X = project(X, param.R, param.sample_mean);

% For a novel sample x, its hash bits can be computed fast by first 
% determining its nearest prototype according to (1), and then assigning 
% the binary code according to (2).

bin = [];
for m = 1:M
    X_sub = X(:, (m-1)*(dim/M)+1 : m*(dim/M));
    [idx, ~] = yael_nn(P{m}', X_sub');
    bin = [bin C{m}(idx)];
end

end
