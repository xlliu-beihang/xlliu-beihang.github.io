function evaluation_info = evaluateKMH(data, param)

tic;
param = trainKMH(double(data.train_data'), param);
trainT = toc;

[B_db, U] = compressKMH(data.db_data', param);
tic;
[B_tst, U] = compressKMH(data.test_data', param);
compressT = toc;

evaluation_info = performance(B_tst, B_db, data.groundtruth, param);
evaluation_info.trainT = trainT;
evaluation_info.compressT = compressT;