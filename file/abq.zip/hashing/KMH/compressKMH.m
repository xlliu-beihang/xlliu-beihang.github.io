function [B U] = compressKMH(X, param)

R = param.R;
centers_table = param.centers_table;
sample_mean = param.sample_mean;
M = param.nbits/param.nsubit;
b = param.nsubit;
%%% projection

X = project(X, R, sample_mean);

D = size(X,2);
d = ceil(D / M);

lut = generate_lut(b);

U = zeros(size(X,1), M*b);

for m = 1:M    
    distX=distMat(X(:,(m-1)*d+1:min(m*d,D)),centers_table{m},0);

    [distX, idx_centers]=min(distX,[],2);
    clear distX;
    
    U(:, (1:b)+(m-1)*b) = lut(idx_centers,:);
end

B = compactbit(U);
end