function param = trainKMH(X, param)
M = param.nbits/param.nsubit;
b = param.nsubit;
num_iter = param.max_iter;
lambda = param.lambda;
%%% projection

[param.R, param.sample_mean] = projection_optimized_product_quantization(X, M);

Xtraining_proj = project(X, param.R, param.sample_mean);

%%% affinity_preserving_PQ

param.centers_table = affinity_preserving_PQ(Xtraining_proj, M, b, num_iter, lambda);
end