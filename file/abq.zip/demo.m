% Adaptive Binary Quantization for Fast Nearest Neighbor Search
% Zhujin Li, Xianglong Liu, Junjie Wu, Hao Su
% ECAI, 2016 
% Contact: xlliu@nlsde.buaa.edu.cn
% This package contains a demo code for the above paper.
% We appreciate your citation and any bug report. Thanks!

clear;
clc;
warning off;
%parpool; %for higher version of Matlab
matlabpool local;
addpath(genpath('./hashing/'));
addpath(genpath('./tool/'));

%% Construct dataset
ntrain = 5000;  % number of training data
nn = 10;        % number of nearest neighbors
exp_data = construct_dataset(ntrain, 'siftsmall', nn);

%% Evaluate hashing methods
nbits = [64 128];
pos = [1 1e1:1e1:5e2];
for i = 1:length(nbits)
    fprintf('%d bits:\n', nbits(i));
    
    %% ABQ
    ABQparam.pos = pos;
    ABQparam.nbits = nbits(i);
    ABQparam.iter = 10;     % iter: number of iterations, usually 10 is enough
    if nbits(i) <= 64       % b: number of bits in each subspace; recommended setting:
        ABQparam.b = 4;     %     b = 4, nbit <= 64 for sift features
    else                    %     b = 8, otherwise
        ABQparam.b = 8;
    end
    ABQ_eva_info{i} = evaluateABQ(exp_data, ABQparam);
    fprintf('[ABQ] MAP: %f\t Train time: %f\n', ABQ_eva_info{i}.AP, ABQ_eva_info{i}.trainT);
    
    %% KMH
    KMHparam.pos = pos;
    KMHparam.nbits = nbits(i);
    KMHparam.lambda = 10;
    KMHparam.max_iter = 50;
    if nbits(i) <= 32
        KMHparam.nsubit = 2;
    else
        KMHparam.nsubit = 4;
    end
    KMH_eva_info{i} = evaluateKMH(exp_data, KMHparam);
    fprintf('[KMH] MAP: %f\t Train time: %f\n', KMH_eva_info{i}.AP, KMH_eva_info{i}.trainT);

    %% ITQ
    ITQparam.nbits = nbits(i);
    ITQparam.pos = pos;
    ITQparam.iter = 50;
    ITQ_eva_info{i} = evaluateITQ(exp_data, ITQparam);
    fprintf('[ITQ] MAP: %f\t Train time: %f\n', ITQ_eva_info{i}.AP, ITQ_eva_info{i}.trainT);
    
end

%% Show recall curves
figure;
for i = 1:length(nbits)
    subplot(1, 2, i);
    title([num2str(nbits(i)) ' bits']);
    xlabel('# top retrieved samples');
    ylabel('Recall');
    hold on;
    plot(pos, ABQ_eva_info{i}.recall, 'r-');
    plot(pos, KMH_eva_info{i}.recall, 'g-');
    plot(pos, ITQ_eva_info{i}.recall, 'b-');
    legend('ABQ', 'KMH', 'ITQ');
end

%delete(gcp('nocreate'));%close parpool;
matlabpool close