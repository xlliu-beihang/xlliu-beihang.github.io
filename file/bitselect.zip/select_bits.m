function idx_sub = select_bits(graph, nbits, nsubits)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Bit Selection using Normalized Dominant Set
% For more details, please refer the paper
% Xianglong Liu, Junfeng He, Bo Lang and Shih-Fu Chang.
% Hash Bit Selection: a Unified Solution for Selection Problems in Hashing.
% IEEE CVPR, 2013
% Contact: xlliu@nlsde.buaa.edu.cn
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

addpath('./meanshift');

p =  graph.p;
E = graph.E;

%% mode seeking
H = diag(p)*E*diag(p);

min_maxima = 1e-3;%dominant selection threshold
term_thrd = 1e-6;

nbits_select = 0;
bits_select = [];
bits_remain = [1:nbits];
while(nbits_select < nsubits)
    nbits_remain = nbits-nbits_select;
    %% repliator dynamics
    Hr = H(bits_remain, bits_remain);
    ind = find(Hr > 0);
    [row, col] = ind2sub([nbits_remain, nbits_remain], ind);
    A = [row, col, Hr(ind)];    
    [~, ind_sort] = sort(row);
    A = A(ind_sort, :);
    acti = A(:,1) < A(:,2);
    A = double(A(acti, :));

    [maxima f] = ReplicatorEquation(A, [nbits_remain term_thrd 1]);
    
%     %% matlab quadprog
%     A = -H(bits_remain, bits_remain);
%     Aeq = ones(1, nbits_remain);
%     beq = 1;
%     lb = zeros(nbits_remain, 1);
%     x0 = ones(nbits_remain, 1)/nbits_remain;
%     opts = optimset('LargeScale', 'off');
%     maxima = quadprog(double(A), [], [], [], Aeq, beq, lb, [], x0, opts); 
    
    [v, idx] = sort(maxima,'descend');
    tr_pos = find(v >= eps*10, 1, 'last');%v(1)*min_maxima
    bits_select = [bits_select bits_remain(idx(1:tr_pos))];
    bits_remain(idx(1:tr_pos)) = [];
    nbits_select = nbits_select + tr_pos;
end
idx_sub = bits_select(1:nsubits);


