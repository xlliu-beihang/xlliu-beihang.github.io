
Xianglong Liu, Junfeng He, Bo Lang and Shih-Fu Chang.
Hash Bit Selection: a Unified Solution for Selection Problems in Hashing.
IEEE CVPR, 2013
Contact: xlliu@nlsde.buaa.edu.cn


This package contains a demo code for the above paper.

Important files are:

1) demo.m: the demo codes showing both precision and recall performances
2) construct_dataset.m: generate training data
3) init_bits.m: generate the bit pool
4) refine_graph.m: build the graph representation for all candidate bits
5) select_bits.m: perform bit selection using the proposed normalized dominant set

Also some tools:
1) LSH: randome projection based locality sensitive hashing
2) meanshift: an efficient solution to the quadratic programming [H. Liu and S. Yan. ICML 2010]
3) tool: performance evaluating tools

Important note: 
1) it would be better to tune the paramters lambda and gamma for differnet datasets
2) to run the demo, download the MNIST data from our website: http://www.nlsde.buaa.edu.cn/~xlliu

We appreciate any bug report. Thanks!
