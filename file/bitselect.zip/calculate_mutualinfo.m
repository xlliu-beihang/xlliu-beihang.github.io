function info =  calculate_mutualinfo(X, Y, C)

nelem = length(C);
nsample = length(X);
x_hist = histc(X, [0:1:nelem-1])/nsample;
y_hist = histc(Y, [0:1:nelem-1])/nsample;
xy_hist = reshape(histc((X+Y)*2-(X-Y), [0 1 3 4])/nsample, [nelem nelem]);

% x_hist = zeros(1, nelem);
% y_hist = zeros(1, nelem);
% xy_hist = zeros(nelem);
% 
% for i = 1:nelem
%     X_Ci = find(X==C(i));
%     x_hist(i) = length(X_Ci)/length(X);
%     y_hist(i) = length(find(Y==C(i)))/length(Y);
%     for j = 1:nelem
%         Y_Cj = find(Y(X_Ci)==C(j));
%         xy_hist(i,j) = length(Y_Cj)/length(X);        
%     end
% end

info = 0;
for i = 1:nelem
    for j = 1:nelem
         if(xy_hist(i,j) ~= 0)
            info = info + xy_hist(i,j)*log2(xy_hist(i,j)/(x_hist(i)* y_hist(j)));
         end
    end
end

info = max(0, info);

% x_info = 0;
% y_info = 0;
% xy_info = 0;
% for i = 1:nelem
%     if(x_hist(i) ~= 0)
%         x_info = x_info-x_hist(i)*log2(x_hist(i));
%     end
%     if(y_hist(i) ~= 0)
%         y_info = y_info-y_hist(i)*log2(y_hist(i));
%     end
%     for j = 1:nelem
%         if(xy_hist(i,j) ~= 0)
%             xy_info = xy_info - xy_hist(i,j)*log2(xy_hist(i,j));
%         end
%     end
% end
% info = max(0, x_info + y_info - xy_info);

