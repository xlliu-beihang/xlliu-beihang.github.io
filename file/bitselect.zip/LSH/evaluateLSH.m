function evaluation_info=evaluateLSH(data, param)

dbdata = data.db_data;
tstdata = data.test_data;
trndata = data.train_data;
groundtruth = data.groundtruth;

tic;
param = trainLSH(double(trndata'),param);
trainT=toc;

%%% Compression Time
[B_db, U] = compressLSH(double(dbdata'), param);
tic;
[B_tst, U] = compressLSH(double(tstdata'), param);
compressT=toc;

evaluation_info = performance(B_tst, B_db, groundtruth, param);
evaluation_info.trainT = trainT;
evaluation_info.compressT = compressT;