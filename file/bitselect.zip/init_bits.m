function [hfunc, graph] = init_bits(data, nbits, methods)

if(nargin < 3)
    methods = {'lsh'};
end

train_data = data.train_data;
test_data = data.test_data;
db_data = data.db_data;
S = data.S;
k = data.nneighbors;
n = data.train_num;
n_test = size(data.test_data, 2);
n_db = size(data.db_data, 2);

%% generate bits
nmethods = length(methods);
nbits_per_method = round(nbits/nmethods);
U_train = zeros(n, nbits, 'uint8');
U_test = zeros(n_test, nbits, 'uint8');
U_db = zeros(n_db, nbits, 'uint8');
for i = 1:nmethods
    idx = [nbits_per_method*(i-1)+1: min(nbits_per_method*i, nbits)];
    param.nbits = min(nbits_per_method, nbits-idx(1)+1);
    if(strcmp('lsh', methods{i}))
        addpath('./LSH');
        param =trainLSH(double(train_data'), param);
        [~, U1] = compressLSH(double(train_data'), param);        
        [~, U2] = compressLSH(double(test_data'), param);        
        [~, U3] = compressLSH(double(db_data'), param);
    elseif(strcmp('pcah', methods{i}))
        addpath('./hashing/PCAH');
        param = trainPCAH(data, param);%
        [~, U1] = compressPCAH(double(train_data'), param);
        [~, U2] = compressPCAH(double(test_data'), param);
        [~, U3] = compressPCAH(double(db_data'), param);
    elseif(strcmp('sh', methods{i}))
        addpath('./hashing/SH');
        param = trainSH(train_data', param);%
        [~, U1] = compressSH(double(train_data'), param);
        [~, U2] = compressSH(double(test_data'), param);
        [~, U3] = compressSH(double(db_data'), param);        
    elseif(strcmp('klsh', methods{i}))
        addpath('./hashing/KLSH');
        param.t = 30;
        param.p = 300;
        param = trainKLSH(data, param);
        [~, U1] = compressKLSH(double(train_data'), param);
        [~, U2] = compressKLSH(double(test_data'), param);
        [~, U3] = compressKLSH(double(db_data'), param);
    elseif(strcmp('itq', methods{i}))
        addpath('./hashing/ITQ');
        param.rand = 0;        
        param = trainITQ(data, param);
        [~, U1] = compressITQ(double(train_data'), param);
        [~, U2] = compressITQ(double(test_data'), param);
        [~, U3] = compressITQ(double(db_data'), param);
    elseif(strcmp('pca', methods{i}))   
        addpath('./hashing/ITQ');
        param.rand = 1;        
        param = trainITQ(data, param);
        [~, U1] = compressITQ(double(train_data'), param);
        [~, U2] = compressITQ(double(test_data'), param);
        [~, U3] = compressITQ(double(db_data'), param);
    elseif(strcmp('sph', methods{i}))
        addpath('./hashing/SPH');
        param = trainSPH(double(train_data'), param);
        [~, U1] = compressSPH(double(train_data'), param);
        [~, U2] = compressSPH(double(test_data'), param);
        [~, U3] = compressSPH(double(db_data'), param);
    elseif(~isempty(strfind(methods{i}, 'dbh')))%strcmp('dbh', methods{i}))
        addpath('./hashing/DBH');
        param.gray = str2num(methods{i}(4));
	if(length(methods{i})>4)
	    param.inith = methods{i}(5:end);
	end
        param = trainDBH(data, param);%
        [~, U1] = compressDBH(double(train_data'), param);
        [~, U2] = compressDBH(double(test_data'), param);
        [~, U3] = compressDBH(double(db_data'), param);
    elseif(strcmp('rmmh', methods{i}))
        addpath('./hashing/RMMH');
        param.M = 32;
        param = trainRMMH(train_data', param);%
        [~, U1] = compressRMMH(double(train_data'), param);
        [~, U2] = compressRMMH(double(test_data'), param);
        [~, U3] = compressRMMH(double(db_data'), param);
end
    U_train(:, idx) = U1;
    U_test(:, idx) = U2;
    U_db(:, idx) = U3;
end
% hfunc.w =param.w;% param.pc;%
% hfunc.b = zeros(1, nbits);%param.sampleMean*hfunc.w;%
hfunc.U_db = U_db;
hfunc.U_test = U_test;
hfunc.U_train = U_train;

U = single(U_train);
clear U_db U_test U_train

data_num = size(train_data, 2);
% L = full(diag(sum(S))-S);
L = eye(data_num)-diag(sum(S).^(-0.5))*S*diag(sum(S).^(-0.5));%diag(sum(S))-S;%

%% build graph by calculating similarity preservation and mutul information
%% spectral
p = diag(U'*L*U);

%% inner product
% %% mutual information
E = zeros(nbits);
for i = 1:nbits
    for j = i+1:nbits
        E(i, j) = calculate_mutualinfo(single(U(:,i)), single(U(:,j)), [0 1]);
    end
end
E = E' + E;

graph.p = p;
graph.E = E;
