%% bit slection demo
nbits = 500; % the pool size
nsubits = 32; % the number of selected bits
nsample = 3000; % traning size
nn = 30; % the number of neighbors for each training samples
pos = [1 2 3 5 10 20 50 100 300 500 1000 2000 3000 1e4 2e4];
param.pos = pos;

nround = 5; % the number of runs

%% parameters, need to be tuned
gamma = 0.25;
lambda = 1;

hashmethods = {'lsh'};
nhmethods = length(hashmethods);
methods = {'NDomSet'};
nmethods = length(methods);% normalized dominant set

%% selection
for n = 1:nround
    exp_data = construct_dataset(nsample, nn);    
    [hfunc graph] = init_bits(exp_data, nbits, hashmethods);      
    
    rgraph = refine_graph(graph, gamma, lambda);
    
    for i = 1:nhmethods + 1 
        param.nbits = nsubits;
        if(i <= nhmethods)%% basic hashing methods
            idx_sub = round(nbits/nhmethods)*(i-1)+[1:nsubits];
        else %% selection methods
            idx_sub = select_bits(rgraph, nbits, nsubits); 
        end

        B_db = compactbit(hfunc.U_db(:,idx_sub)>0);
        B_tst = compactbit(hfunc.U_test(:,idx_sub)>0);
        evaluation_info{i, n} = performance(B_tst, B_db, exp_data.groundtruth, param);
    end
end


%% show results
MAP = zeros(nmethods+nhmethods,1);
PH2 = zeros(nmethods+nhmethods,1);
R = zeros(nmethods+nhmethods,length(pos));
P = zeros(nmethods+nhmethods,length(pos));
for n = 1:nround
    for i = 1:nhmethods+nmethods
            MAP(i) = MAP(i) +  evaluation_info{i, n}.AP/nround;
            PH2(i) = PH2(i) +  evaluation_info{i, n}.PH2/nround;
            R(i,:) = R(i,:) +  evaluation_info{i, n}.recall/nround;
            P(i,:) = P(i,:) +  evaluation_info{i, n}.precision/nround;
    end
end

markers = {'b--', 'r-', 'g-.',  'm:'};
%% show recall
figure('Color',[1 1 1]); hold on;
for i = 1:nhmethods+nmethods
    plot(pos(1:11), R(i, 1:11), markers{i}, 'LineWidth', 2);
end
set(gca,'fontsize',14);

legend([hashmethods methods], 2);
xlabel('number of top retrieved samples', 'Fontsize', 16);
ylabel('recall', 'Fontsize', 16);
box on;
grid on;
hold off;

%% show precision
figure('Color',[1 1 1]); hold on;
for i = 1:nhmethods+nmethods
    plot(pos(1:11), P(i, 1:11), markers{i}, 'LineWidth', 2);
end
set(gca,'fontsize',14);
legend([hashmethods methods], 2);
xlabel('number of top retrieved samples', 'Fontsize', 16);
ylabel('precision', 'Fontsize', 16);
box on;
grid on;
hold off;

%% show MAP and PH2
figure('Color',[1 1 1]); hold on;
Y = [MAP'; PH2'];
bar(Y, 'grouped')
set(gca,'fontsize',14);
legend([hashmethods methods], 2);
ylabel('MAP/PH2', 'Fontsize', 14);
box on;
grid on;
hold off;

