function exp_data = construct_dataset(n, k)
%data constrcution
addpath('./tool/');

rand('state', sum(100*clock));
train_num = n; %number of traning data
test_num = 1000;  %number of test data
sneighbors = k;%number of neighbors of same labels
dneighbors = 2*k;%number of neighbors of different labels
nneighbors = sneighbors + dneighbors;

load('MNIST_gnd_release.mat'); %released by Wang et al., ICML 2010 
vtrain = MNIST_trndata';
clear MNIST_trndata;
vbase = vtrain;
vquery = MNIST_tstdata';

ntrain = size (vtrain, 2);
nbase = size (vbase, 2);
nquery = size (vquery, 2);
d = size (vtrain, 1);

for i = 1:nquery
   ids_gnd{i} = find( MNIST_trnlabel == MNIST_tstlabel(i));
end
 
train_idx = randsample(ntrain, train_num);
train_data = vtrain(:, train_idx);
train_lables = MNIST_trnlabel(train_idx);

meanVec = mean(train_data, 2);
train_data = train_data - repmat(meanVec, 1, train_num);

data_num = nbase;
db_data = vbase - repmat(meanVec, 1, data_num);
clear vbase

test_idx = randsample(nquery, test_num);
test_data = vquery(:, test_idx);
test_data = test_data - repmat(meanVec, 1, test_num);

DIST = distMat(train_data', train_data', 0) ;

S = zeros(train_num); % can be tailored for different scenarios
NN = zeros(train_num, nneighbors);
for i = 1:train_num    
    sidx = find(train_lables==train_lables(i));
    didx = find(train_lables~=train_lables(i));
    
    [~, so] = sort(DIST(i,sidx), 'ascend');    
    [~, do] = sort(DIST(i,didx), 'ascend');
    
    S(i, sidx(so(1+[1:sneighbors]))) = DIST(i, sidx(so(1+[1:sneighbors])));
    NN(i,:) = [sidx(so(1+[1:sneighbors])) didx(do([1:dneighbors]))];
end
S = (S+S')/2;
dist = max(S(:));
S=sparse((S>0).*exp(-S/dist));

groundtruth = zeros(test_num, data_num, 'uint8');
for i = 1:test_num
       groundtruth(i, ids_gnd{test_idx(i)}) = 1;
end

exp_data.nneighbors = nneighbors; %number of nneighbors per class
exp_data.train_num = train_num;
exp_data.train_data = train_data;
exp_data.valid_data = train_data;

exp_data.test_data = test_data;
exp_data.groundtruth = groundtruth;

exp_data.S = sparse(S);
exp_data.NN = NN;
exp_data.db_data = db_data;

  
