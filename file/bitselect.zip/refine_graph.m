function rgraph = refine_graph(graph, gamma, lambda)

p = graph.p;
E = graph.E;

rp = p;
rp = (rp-min(rp))/(max(rp)-min(rp)+eps);
rp = exp(-gamma*rp);%gamma = 1;
rgraph.p = rp;

nbits = length(rp);

rE = E;
minE = min(min(rE+eye(nbits)));
maxE = max(rE(:));
rE = (rE-minE+eye(nbits)*minE)/(maxE-minE+eps);
rE = exp(-lambda*rE) - eye(nbits);%gamma = 1; %method 4

rgraph.E = max(0, rE);
