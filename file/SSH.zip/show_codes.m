function show_codes(method, Y, data_num, L, A)
colors = {'r','b','k','m'};
num_blob = data_num/4;
figure; hold on;
for i = 1:4
    idx = [1:num_blob]+num_blob*(i-1);
    plot(Y(1,idx),Y(2,idx), [colors{i} 'o'], ...
     'MarkerSize', 4, 'MarkerFaceColor', colors{i});
end
for i = 1:data_num
idx = find(A(i,:) == 1);
for j = 1:length(idx)
    plot([Y(1,i) Y(1,idx(j))], [Y(2,i) Y(2,idx(j))], 'g-');
end
end
hold off;
Y = sign(Y);%zeros(size(U));
fprintf('%s error: %f\n', method, trace(Y*L*Y'));