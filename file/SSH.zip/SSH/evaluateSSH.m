function evaluation_info=evaluateSSH(data,param)

dbdata = data.db_data;
tstdata = data.test_data;
groundtruth = data.groundtruth;

tic;
param = trainSSH(data, param);
trainT=toc;

[B_db U] = compressSSH(double(dbdata'), param);
tic;
[B_tst, U] = compressSSH(double(tstdata'), param);
compressT=toc;  

evaluation_info = performance(B_tst, B_db, groundtruth, param);
evaluation_info.trainT = trainT;
evaluation_info.compressT = compressT;