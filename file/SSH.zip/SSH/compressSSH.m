function [B, U] = compressSSH(X, SSHparam)
%
% [B, U] = compressSSH(X, SHparam)

if(SSHparam.useanchor == 1)
    [n,dim] = size(X);
    Anchor = SSHparam.landmarks';
    m = size(Anchor,1);
    s = SSHparam.nn;
    sigma = SSHparam.sigma;
    
    %% get Z
    Z = zeros(n,m);
    Dis = distMat(X,Anchor);
    clear X;
    clear Anchor;

    val = zeros(n,s);
    pos = val;
    for i = 1:s
        [val(:,i),pos(:,i)] = min(Dis,[],2);
        tep = (pos(:,i)-1)*n+[1:n]';
        Dis(tep) = 1e60; 
    end
    clear Dis;
    clear tep;
    val = exp(-val/(1/1*sigma^2));
    val = repmat(sum(val,2).^-1,1,s).*val; %% normalize
    tep = (pos-1)*n+repmat([1:n]',1,s);
    Z([tep]) = [val];
    Z = sparse(Z);
    clear tep;
    clear val;
    clear pos;
    X = Z;
end


[Nsamples Ndim] = size(X);
nbits = SSHparam.nbits;

U = X*SSHparam.w + ones(Nsamples,1)*SSHparam.b';
B = compactbit(U>0);
U = (U>0);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function cb = compactbit(b)
%
% b = bits array
% cb = compacted string of bits (using words of 'word' bits)

[nSamples nbits] = size(b);
nwords = ceil(nbits/8);
cb = zeros([nSamples nwords], 'uint8');

for j = 1:nbits
    w = ceil(j/8);
    cb(:,w) = bitset(cb(:,w), mod(j-1,8)+1, b(:,j));
end


