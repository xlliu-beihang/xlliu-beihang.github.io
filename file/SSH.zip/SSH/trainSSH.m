function param = trainSSH(data, param)
%
% Input
%   X = features matrix [Nsamples, Nfeatures]
%   SHparam.nbits = number of bits (nbits do not need to be a multiple of 8)
%
%
% Shared Subspace Hashing
X = data.train_data;
[dim nsample] = size(X);
nbits = param.nbits;
alpha = param.alpha;
beta = param.beta;
gamma = param.gamma;
% param.rdim = param.nbits;
rdim = param.rdim;

max_iter = param.max_iter;
tol = param.tol;

% L = diag(sum(data.S)) - data.S;
L = eye(nsample)-diag(sum(data.S).^(-0.5))*data.S*diag(sum(data.S).^(-0.5));
% L = -data.S;
if(param.useanchor == 1)
    landmarks = data.landmarks;
    nlandmarks = size(landmarks, 2);
    Z = zeros(nsample, nlandmarks);
    Dis = distMat(X',landmarks');

    s = param.nn;
    n = nsample;
    val = zeros(nsample,s);
    pos = val;
    for i = 1:s
        [val(:,i),pos(:,i)] = min(Dis,[],2);
        tep = (pos(:,i)-1)*n+[1:n]';
        Dis(tep) = 1e60; 
    end
    clear Dis;
    clear tep;

    sigma = mean(val(:,s).^0.5);
    val = exp(-val/(1/1*sigma^2));
    val = repmat(sum(val,2).^-1,1,s).*val; %% normalize
    tep = (pos-1)*n+repmat([1:n]',1,s);
    Z([tep]) = [val];
    Z = sparse(Z);
    clear tep;
    clear val;
    clear pos;

    %% compute eigensystem 
    lamda = sum(Z);
    L = eye(n) - Z*diag(lamda.^-1)*Z';
    X = Z';
    dim = nlandmarks;
end

%%initialize
% Theta = eye(dim);
% Theta = Theta(1:rdim, :);

C = cov(double(X'));
[Theta l] = eigs(C, rdim);
Theta = Theta';

% THETA = rand(dim);
% THETA = THETA + THETA';
% [E D] = eigs(double(THETA), rdim);
% Theta = E';
P = eye(nsample)-(1/nsample)*ones(nsample,1)*ones(1, nsample);

iter = 0;
pre_obj = Inf;

while(iter < max_iter)
    %% compute Y, W, V
    Theta_sym = Theta'*Theta;
    M = alpha*(alpha*(X*P*X')+(beta+gamma)*eye(dim)-beta*Theta_sym)\X*P;
    M_hat = (eye(nsample)-M'*X);
    C = full(L) +alpha*(M_hat*P*M_hat')-beta*(M'*Theta_sym*M)+(beta+gamma)*(M'*M);
    
    [E D] = eigs(double(C), nbits+1, 'sm');
    [~,idx] = sort(diag(abs(D)));
    E = E(:,idx(2:end));
    Y = E';
    Y = ones(size(E'))*(-1);
    Y (E' >= 0) = 1;
    obj = trace(Y*C*Y');
    if (pre_obj-obj<max(obj*tol,tol))
        break;
    else        
        pre_obj = obj;
    end
    iter = iter + 1;
    
    W = M*Y';
    b = (Y-W'*X)*ones(nsample,1)*(1/nsample);
    V = Theta*W;     
    
   %% compute Theta
    C = W*W'; 
    [E D] = eigs(double(C),rdim);
    Theta = E';    
end

param.w = W;
param.b = b;
param.theta = Theta;
param.v = V;
if(param.useanchor == 1)
    param.sigma = sigma;
    param.landmarks = landmarks;
end

