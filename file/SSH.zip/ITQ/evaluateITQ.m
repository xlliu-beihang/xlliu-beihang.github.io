function evaluation_info = evaluateITQ(data, param)

tic;
param = trainITQ(data, param);
trainT=toc;
    
dbdata = data.db_data;
tstdata = data.test_data;
groundtruth = data.groundtruth;

[B_db, U] = compressITQ(double(dbdata'), param);
tic;
[B_tst, U] = compressITQ(double(tstdata'), param);
compressT=toc;

evaluation_info = performance(B_tst, B_db, groundtruth, param);
evaluation_info.trainT = trainT;
evaluation_info.compressT = compressT;