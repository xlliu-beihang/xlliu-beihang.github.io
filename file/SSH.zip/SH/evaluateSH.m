function evaluation_info=evaluateSH(data,param)
dbdata = data.db_data;
tstdata = data.test_data;
groundtruth = data.groundtruth;

tic;
param = trainSH(data, param);
trainT=toc;
 
%%% Compression Time
[B_db, U] = compressSH(double(dbdata'),param);
tic;
[B_tst, U] = compressSH(double(tstdata'),param);
compressT=toc;

evaluation_info = performance(B_tst, B_db, groundtruth, param);
evaluation_info.trainT = trainT;
evaluation_info.compressT = compressT;
% pos = SPHparam.pos;
% poslen = length(pos);
% label_r = zeros(1, poslen);
% label_p = zeros(1, poslen);
% label_ar = zeros(1, poslen);
% label_ahd = zeros(1, poslen);
% label_ap = zeros(1, 1);
% label_ph2 = zeros(1, 1);
% for n = 1:size(tstdata, 2)%length(tstlabel)
%     % compute your distance
%     D_code = hammingDist(B_tst(n,:),B_trn);
%     D_truth = groundtruth{n};%ground truth
%      
%     [P, R, AR, AHD, AP, PH2] = precall2(D_code, D_truth, pos);
% 
%     label_r = label_r + R(1:poslen);
%     label_p = label_p + P(1:poslen);
%     label_ar = label_ar + AR(1:poslen);
%     label_ahd = label_ahd + AHD(1:poslen);
%     label_ap = label_ap + AP;
%     label_ph2 = label_ph2 + PH2;
% end
% evaluation_info.recall=label_r/size(tstdata, 2);
% evaluation_info.precision=label_p/size(tstdata, 2);
% evaluation_info.AR=label_ar/size(tstdata, 2);
% evaluation_info.AHD=label_ahd/size(tstdata, 2);
% evaluation_info.AP=label_ap/size(tstdata, 2);
% evaluation_info.PH2=label_ph2/size(tstdata, 2);
% evaluation_info.SPHparam=SPHparam;