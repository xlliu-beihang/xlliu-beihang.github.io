%% collaborative hashing for recommendation (cross-view search)
%% please cite our CVPR 2014 paper
%% Xianglong Liu, Junfeng He, Cheng Deng, Bo Lang. Collaborative Hashing. IEEE CVPR, 2014.

addpath(genpath('./hashing'));
addpath('./tool');
nbits = [16 32 64];%:8:64];

M = [1 5 10 20 50 100 200 500 1000:1000:3000];

exp_data = construct_dataset_movielen();

pos = [M size(exp_data.groundtruth, 2)];
n = 1;
for i = 1:length(nbits)
    %% Colaborative Hashing
    CHparam.nbits = nbits(i);
    CHparam.pos = pos;
    CHparam.lambda = 1e0;%3/(nbits(i)/16);
    CHparam.sparse = 1;
    CH_eva_info{i,n} = rateCH(exp_data, CHparam);

    %% Laplacian Co-Hashing
    LCHparam.nbits = nbits(i);
    LCHparam.pos = pos;
    LCH_eva_info{i,n} = rateLCH(exp_data, LCHparam); 
end


%% plot results
npos = length(pos);
nb = length(nbits);
colors = {'bo-', 'rs-'};
methods = {'LCH', 'CH'};
nmethods = length(methods);
for i = 1:nmethods
     eva = eval([methods{i} '_eva_info']);
     for j = 1:nb 
        MAP(i,j) = eva{j,n}.AP;            
        NDCG(i,j) =  eva{j,n}.ndcg(2);
    end
end

%% MAP
figure('Color',[1 1 1]); hold on;
for i = 1:nmethods
    plot(nbits, MAP(i,:), colors{i}, 'LineWidth', 2);
end
set(gca,'XTick',nbits);
set(gca,'fontsize',14);
legend(methods,4);
xlim([min(nbits) max(nbits)]);
xlabel('number of bits', 'Fontsize', 16);
ylabel('MAP', 'Fontsize', 16);
box on;
grid on;
hold off;

%% NDCG
figure('Color',[1 1 1]); hold on;
for i = 1:nmethods
    plot(nbits, NDCG(i,:), colors{i}, 'LineWidth', 2);
end
set(gca,'XTick',nbits);
set(gca,'fontsize',14);
legend(methods,4);
xlim([min(nbits) max(nbits)]);
xlabel('number of bits', 'Fontsize', 16);
ylabel(['NDCG@' num2str(pos(2))], 'Fontsize', 16);
box on;
grid on;
hold off;

