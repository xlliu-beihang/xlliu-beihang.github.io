function exp_data = construct_dataset_20news()
%data constrcution
addpath('./tool/');
addpath('./data/20news');
load '20Newsgroups.mat';
% addpath('./data/Reuters');
% load 'Reuters.mat';

train_num = length(trainIdx); %number of traning data
test_num = length(testIdx);  %number of test data

% [v, tid] = sort(sum(fea>0), 'descend');
% term_num = 10000;
% stidx = find(v<0.5*size(fea,1), 1, 'first');
% fea = fea(:, tid(stidx+randperm(term_num)));

[data ~] = tfidf(fea);
data = fea';
nr = sqrt(sum(data.^2, 1));
[idx,jdx,vv] = find(nr);
nr = sparse(idx,jdx,1./vv);
data = bsxfun(@times, data, nr);

% d = 1./sum(data);
% data =bsxfun(@times, data, d);

train_data = data(:, trainIdx);
% [train_data idf] = tfidf(train_data');

test_data = data(:, testIdx);
% [test_data ~] = tfidf(test_data', idf); 
test_label = gnd(testIdx);

gnd(testIdx) = [];

db_num = size(train_data, 2);
groundtruth =  zeros(test_num, db_num)>0;
for i = 1:test_num
    groundtruth(i, gnd == test_label(i)) = 1;
end

d = sum(train_data,2);
ni1 = d~=0;

train_data = train_data(ni1,:);
test_data = test_data(ni1,:);

d = sum(train_data,1);
ni2 = d~=0;

train_data = train_data(:, ni2);
groundtruth = groundtruth(:, ni2);

d = sum(groundtruth,2);
ni3 = d~=0;
test_data = test_data(:,ni3);
groundtruth = groundtruth(ni3,:);

exp_data.ndim = 1; %number of nneighbors per class
exp_data.train_num = train_num;%length(trn_coarse_labels);
exp_data.train_data = train_data;

exp_data.db_data = train_data;
exp_data.test_data{1} = test_data;%single label test
exp_data.groundtruth{1} = groundtruth;
  
  
