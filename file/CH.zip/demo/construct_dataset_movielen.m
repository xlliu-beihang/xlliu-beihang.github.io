function exp_data = construct_dataset_movielen()
%data constrcution
addpath('./tool/');
addpath('./data/ml-1m');

load 'movielen1M.mat';

% data = normc(data);
rand('state', sum(100*clock));
[idi idj vv] = find(data);
[user_num item_num] = size(data); 
rate_num = length(idi);

randIdx = randperm(rate_num);
trainIdx = randIdx(1:floor(rate_num*0.8));
testIdx = randIdx(floor(rate_num*0.8)+1:rate_num);

train_data = sparse(idi(trainIdx), idj(trainIdx), vv(trainIdx), user_num, item_num)';
test_data = sparse(idi(testIdx), idj(testIdx), vv(testIdx), user_num, item_num)';

groundtruth = data;

exp_data.ndim = 1; %number of nneighbors per class
exp_data.train_num = user_num;%length(trn_coarse_labels);
exp_data.train_data = train_data;

exp_data.db_data = train_data;
exp_data.test_data{1} = test_data;%single label test
exp_data.groundtruth{1} = groundtruth;%single label test
  
  
