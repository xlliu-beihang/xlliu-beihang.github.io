%% collaborative hashing for nearest neighbor search
%% need a number of memory 
%% please cite our CVPR 2014 paper
%% Xianglong Liu, Junfeng He, Cheng Deng, Bo Lang. Collaborative Hashing. IEEE CVPR, 2014.

addpath(genpath('./hashing'));
addpath('./tool');
nbits = [16 32 64];

M = [1 5 10 20 50 100 200 500 1000 2000 3000];
exp_data = construct_dataset_20news();

pos = [M size(exp_data.db_data, 2)];
for i = 1:length(nbits)

    CHparam.nbits = nbits(i);
    CHparam.pos = pos;
    CHparam.lambda = 1e2;% tune for better performance
    CH_eva_info{i,1} = evaluateCH(exp_data, CHparam);

    LCHparam.nbits = nbits(i);
    LCHparam.pos = pos;
    LCH_eva_info{i,1} = evaluateLCH(exp_data, LCHparam);
end

%% plot results
npos = length(pos);
nb = length(nbits);
methods = {'LCH', 'CH'};
nmethods = length(methods);
for i = 1:nmethods
     eva = eval([methods{i} '_eva_info']);
     for j = 1:nb 
        MAP(i,j) = eva{j,1}.AP;    
        P(i,:)  = eva{j,1}.precision;  
        R(i,:)  = eva{j,1}.recall; 
    end
end

%% MAP
colors = {'bo-', 'rs-'};
figure('Color',[1 1 1]); hold on;
for i = 1:nmethods
    plot(nbits, MAP(i,:), colors{i}, 'LineWidth', 2);
end
set(gca,'XTick',nbits);
set(gca,'fontsize',14);
legend(methods,4);
xlim([min(nbits) max(nbits)]);
xlabel('number of bits', 'Fontsize', 16);
ylabel('MAP', 'Fontsize', 16);
box on;
grid on;
hold off;

%% Precision
figure('Color',[1 1 1]); hold on;
for i = 1:nmethods
    plot(pos(1:npos-1), P(i,1:npos-1), colors{i}, 'LineWidth', 2);
end
set(gca,'fontsize',14);
legend(methods,4);
xlabel('number of returned samples', 'Fontsize', 16);
ylabel('precision', 'Fontsize', 16);
box on;
grid on;
hold off;


%% Recall
figure('Color',[1 1 1]); hold on;
for i = 1:nmethods
    plot(pos(1:npos-1), R(i,1:npos-1), colors{i}, 'LineWidth', 2);
end
set(gca,'fontsize',14);
legend(methods,4);
xlabel('number of returned samples', 'Fontsize', 16);
ylabel('recall', 'Fontsize', 16);
box on;
grid on;
hold off;