function [B, U] = compressLCH(X, LCHparam, opt)

N = 1./sum(X,2);
P = LCHparam.P{opt};
T = LCHparam.T{opt};

X = bsxfun(@times, X, N);

U = X*P;
U = full(bsxfun(@minus, U, T));
U = U >= 0;
B = compactbit(U);
