function LCHparam = trainLCH(X, LCHparam)

nbit = LCHparam.nbits;
d1 = sum(X,2);
[idx jdx vv] = find(d1);
d1 = sparse(idx, jdx, 1./sqrt(vv));

d2 = sum(X,1);
[idx jdx vv] = find(d2);
d2 = sparse(idx, jdx, 1./sqrt(vv));

% % X = diag(d1)*X*diag(d2);
X = (bsxfun(@times, X, d1));
X = (bsxfun(@times, X, d2));

[U sigma V] = svds(X,nbit+1);%remove sigma = 1
ni = find(abs(diag(sigma)-1)>1e-6);
U = U(:,ni(1:nbit));

A = diag(d1)*U;
T1 = mean(A);

V = V(:,ni(1:nbit));
B = diag(d2)*V;
T2 = mean(B);

S = diag(1./diag(sigma(ni(1:nbit),ni(1:nbit))));
LCHparam.P{1} = (S*U'*diag(d1))';
LCHparam.P{2} = (S*V'*diag(d2))';
LCHparam.T{1} = T1;
LCHparam.T{2} = T2;
