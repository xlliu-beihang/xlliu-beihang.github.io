function evaluation_info = rateLCH(data, param)

tic;
param = trainLCH(data.train_data, param);
trainT=toc;

[B_u, U] = compressLCH(data.db_data', param, 1);
[B_i, U] = compressLCH(data.db_data, param, 2);

groundtruth = data.groundtruth{1};

evaluation_info = performance_rate(B_u, B_i, groundtruth, param);
evaluation_info.trainT = trainT;